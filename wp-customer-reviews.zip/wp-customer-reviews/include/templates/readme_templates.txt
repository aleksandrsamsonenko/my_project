These are the default templates. These WILL be overwritten when the plugin upgrades. 

If you need to make updates to any templates, you can update them in the plugin settings of WP Customer Reviews Pro.