<?php

class CMA_Category {
	
	const TAXONOMY = 'cma_category';
	
}